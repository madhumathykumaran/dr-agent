"""
Mock ServiceNow API for the Disaster Recovery Compliance Agent System.

This module provides a mock implementation of the ServiceNow API for fetching
Business Continuity Plans (BCP).
"""

from src.mock_apis.servicenow.api import MockServiceNowAPI, mock_servicenow_api

__all__ = ["MockServiceNowAPI", "mock_servicenow_api"]
