"""
Tests for the Tasks Analysis Agent.

This module contains tests for the Tasks Analysis Agent and its interaction
with the PGVector API.
"""

import unittest
import os
from unittest.mock import patch, MagicMock
from datetime import datetime

from src.agents.tasks_analysis.agent import TasksAnalysisAgent
from src.mock_apis.pgvector.api import MockPGVectorAPI
from src.models.data_models import DisasterRecoveryPlan, RecoveryTask, Device, StandardPlan, StandardSection

class MockAssistantAgent:
    def __init__(self, name, system_message, llm_config):
        self.name = name
        self.system_message = system_message
        self.llm_config = llm_config
    
    def generate_reply(self, message):
        return {"content": "Mock reply from assistant agent", "role": "assistant"}

class TestTasksAnalysisAgent(unittest.TestCase):
    """Tests for the Tasks Analysis Agent."""
    
    def setUp(self):
        """Set up the test environment."""
        os.environ["OPENAI_API_KEY"] = "test_api_key"
        
        self.mock_pgvector_api = MagicMock(spec=MockPGVectorAPI)
        
        with patch("autogen.AssistantAgent", MockAssistantAgent):
            self.agent = TasksAnalysisAgent()
            self.agent.pgvector_api = self.mock_pgvector_api
    
    def test_analyze_tasks(self):
        """Test analyzing recovery tasks of disaster recovery plans."""
        plan1 = DisasterRecoveryPlan(
            id="PLAN001",
            app_code="APP001",
            name="DR Plan for APP001",
            description="Description for APP001",
            version="1.0",
            created_at=datetime.now(),
            updated_at=datetime.now(),
            recovery_time_objective=60,
            recovery_point_objective=30,
            tasks=[
                RecoveryTask(
                    id="TASK001",
                    name="Task 1",
                    description="Task 1 description",
                    sequence=1,
                    estimated_duration=30,
                    responsible_team="IT Operations",
                    dependencies=[]
                ),
                RecoveryTask(
                    id="TASK002",
                    name="Task 2",
                    description="Task 2 description",
                    sequence=2,
                    estimated_duration=45,
                    responsible_team="Database Team",
                    dependencies=["TASK001"]
                )
            ],
            devices=[
                Device(
                    id="DEV001",
                    name="Device 1",
                    type="Server",
                    description="Device 1 description",
                    app_code="APP001"
                )
            ]
        )
        
        plan2 = DisasterRecoveryPlan(
            id="PLAN002",
            app_code="APP002",
            name="DR Plan for APP002",
            description="Description for APP002",
            version="1.0",
            created_at=datetime.now(),
            updated_at=datetime.now(),
            recovery_time_objective=120,
            recovery_point_objective=60,
            tasks=[
                RecoveryTask(
                    id="TASK003",
                    name="Task 3",
                    description="Task 3 description",
                    sequence=1,
                    estimated_duration=60,
                    responsible_team="Network Team",
                    dependencies=[]
                )
            ],
            devices=[
                Device(
                    id="DEV002",
                    name="Device 2",
                    type="Network",
                    description="Device 2 description",
                    app_code="APP002"
                )
            ]
        )
        
        plans = [plan1, plan2]
        
        standard_plan = StandardPlan(
            id="STD_TASKS_001",
            name="Standard Disaster Recovery Plan Tasks",
            type="tasks",
            sections=[
                StandardSection(
                    id="SEC_TASKS_001",
                    name="Task Structure",
                    description="Task structure description",
                    requirements=["Requirement 1", "Requirement 2"],
                    best_practices=["Best Practice 1", "Best Practice 2"]
                )
            ]
        )
        
        self.mock_pgvector_api.get_standard_plan_by_type.return_value = standard_plan
        
        self.mock_pgvector_api.analyze_plan_tasks.side_effect = [
            {
                "status": "success",
                "standard_plan_id": "STD_TASKS_001",
                "standard_plan_name": "Standard Disaster Recovery Plan Tasks",
                "overall_compliance_score": 0.85,
                "task_compliance_score": 0.80,
                "section_compliance_score": 0.90,
                "summary": "Summary for plan 1 tasks",
                "gaps": ["Gap 1", "Gap 2"],
                "improvements": ["Improvement 1", "Improvement 2"],
                "section_analyses": [
                    {
                        "section_id": "SEC_TASKS_001",
                        "section_name": "Task Structure",
                        "compliance_score": 0.90,
                        "gaps": ["Gap 1", "Gap 2"],
                        "improvements": ["Improvement 1", "Improvement 2"]
                    }
                ],
                "task_analyses": [
                    {
                        "task_id": "TASK001",
                        "task_name": "Task 1",
                        "compliance_score": 0.75,
                        "gaps": ["Task 1 Gap 1", "Task 1 Gap 2"],
                        "improvements": ["Task 1 Improvement 1", "Task 1 Improvement 2"]
                    },
                    {
                        "task_id": "TASK002",
                        "task_name": "Task 2",
                        "compliance_score": 0.85,
                        "gaps": ["Task 2 Gap 1"],
                        "improvements": ["Task 2 Improvement 1"]
                    }
                ]
            },
            {
                "status": "success",
                "standard_plan_id": "STD_TASKS_001",
                "standard_plan_name": "Standard Disaster Recovery Plan Tasks",
                "overall_compliance_score": 0.75,
                "task_compliance_score": 0.70,
                "section_compliance_score": 0.80,
                "summary": "Summary for plan 2 tasks",
                "gaps": ["Gap 3", "Gap 4"],
                "improvements": ["Improvement 3", "Improvement 4"],
                "section_analyses": [
                    {
                        "section_id": "SEC_TASKS_001",
                        "section_name": "Task Structure",
                        "compliance_score": 0.80,
                        "gaps": ["Gap 3", "Gap 4"],
                        "improvements": ["Improvement 3", "Improvement 4"]
                    }
                ],
                "task_analyses": [
                    {
                        "task_id": "TASK003",
                        "task_name": "Task 3",
                        "compliance_score": 0.70,
                        "gaps": ["Task 3 Gap 1", "Task 3 Gap 2"],
                        "improvements": ["Task 3 Improvement 1", "Task 3 Improvement 2"]
                    }
                ]
            }
        ]
        
        result = self.agent.analyze_tasks(plans)
        
        self.assertEqual(result["status"], "success")
        self.assertEqual(result["data"]["standard_plan_id"], "STD_TASKS_001")
        self.assertEqual(result["data"]["plan_count"], 2)
        self.assertEqual(result["data"]["analyzed_count"], 2)
        self.assertEqual(result["data"]["error_count"], 0)
        self.assertAlmostEqual(result["data"]["avg_compliance_score"], 0.8, places=1)
        self.assertEqual(len(result["data"]["plan_analyses"]), 2)
        
        self.mock_pgvector_api.get_standard_plan_by_type.assert_called_once_with("tasks")
        self.assertEqual(self.mock_pgvector_api.analyze_plan_tasks.call_count, 2)
        
        first_call_args = self.mock_pgvector_api.analyze_plan_tasks.call_args_list[0][0][0]
        self.assertEqual(len(first_call_args), 2)  # Plan 1 has 2 tasks
        self.assertEqual(first_call_args[0]["id"], "TASK001")
        self.assertEqual(first_call_args[1]["id"], "TASK002")
        
        second_call_args = self.mock_pgvector_api.analyze_plan_tasks.call_args_list[1][0][0]
        self.assertEqual(len(second_call_args), 1)  # Plan 2 has 1 task
        self.assertEqual(second_call_args[0]["id"], "TASK003")
    
    def test_process_message_with_plans_data(self):
        """Test processing a message with plans data from the DR Plans Fetcher Agent."""
        plans_data = {
            "plans_data": {
                "data": {
                    "plans": [
                        {
                            "id": "PLAN001",
                            "app_code": "APP001",
                            "name": "DR Plan for APP001",
                            "description": "Description for APP001",
                            "version": "1.0",
                            "created_at": datetime.now().isoformat(),
                            "updated_at": datetime.now().isoformat(),
                            "recovery_time_objective": 60,
                            "recovery_point_objective": 30,
                            "tasks": [
                                {
                                    "id": "TASK001",
                                    "name": "Task 1",
                                    "description": "Task 1 description",
                                    "sequence": 1,
                                    "estimated_duration": 30,
                                    "responsible_team": "IT Operations",
                                    "dependencies": []
                                }
                            ],
                            "devices": [
                                {
                                    "id": "DEV001",
                                    "name": "Device 1",
                                    "type": "Server",
                                    "description": "Device 1 description",
                                    "app_code": "APP001"
                                }
                            ]
                        }
                    ]
                }
            }
        }
        
        self.agent.analyze_tasks = MagicMock(return_value={
            "status": "success",
            "data": {
                "standard_plan_id": "STD_TASKS_001",
                "standard_plan_name": "Standard Disaster Recovery Plan Tasks",
                "plan_count": 1,
                "analyzed_count": 1,
                "error_count": 0,
                "avg_compliance_score": 0.85,
                "plan_analyses": {
                    "PLAN001": {
                        "plan_id": "PLAN001",
                        "app_code": "APP001",
                        "plan_name": "DR Plan for APP001",
                        "task_count": 1,
                        "overall_compliance_score": 0.85,
                        "task_compliance_score": 0.80,
                        "section_compliance_score": 0.90,
                        "summary": "Summary for plan 1 tasks",
                        "gaps": ["Gap 1", "Gap 2"],
                        "improvements": ["Improvement 1", "Improvement 2"],
                        "section_analyses": [],
                        "task_analyses": []
                    }
                }
            }
        })
        
        result = self.agent.process_message(plans_data)
        
        self.assertEqual(result["status"], "success")
        self.assertIn("data", result)
        
        self.agent.analyze_tasks.assert_called_once()
        self.assertEqual(len(self.agent.analyze_tasks.call_args[0][0]), 1)
    
    def test_process_message_no_plans(self):
        """Test processing a message with no plans."""
        message = {}
        
        original_analyze_tasks = self.agent.analyze_tasks
        self.agent.analyze_tasks = MagicMock()
        
        try:
            result = self.agent.process_message(message)
            
            self.assertEqual(result["status"], "error")
            self.assertIn("message", result)
            
            self.agent.analyze_tasks.assert_not_called()
        finally:
            self.agent.analyze_tasks = original_analyze_tasks
    
    def test_process_message_error(self):
        """Test processing a message when an error occurs."""
        plans_data = {
            "plans_data": {
                "data": {
                    "plans": [
                        {
                            "id": "PLAN001",
                            "app_code": "APP001",
                            "name": "DR Plan for APP001",
                            "description": "Description for APP001",
                            "version": "1.0",
                            "created_at": datetime.now().isoformat(),
                            "updated_at": datetime.now().isoformat(),
                            "recovery_time_objective": 60,
                            "recovery_point_objective": 30,
                            "tasks": [],
                            "devices": []
                        }
                    ]
                }
            }
        }
        
        self.agent.analyze_tasks = MagicMock(side_effect=Exception("Test error"))
        
        result = self.agent.process_message(plans_data)
        
        self.assertEqual(result["status"], "error")
        self.assertIn("message", result)
        
        self.agent.analyze_tasks.assert_called_once()

if __name__ == "__main__":
    unittest.main()
