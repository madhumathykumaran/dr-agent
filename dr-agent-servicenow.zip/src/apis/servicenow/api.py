"""
ServiceNow API client for the Disaster Recovery Compliance Agent System.

This module provides a client for interacting with the ServiceNow API to fetch
Business Continuity Plans (BCP).
"""

import logging
import requests
import json
from datetime import datetime
from typing import List, Dict, Any, Optional

from src.models.data_models import DisasterRecoveryPlan, RecoveryTask, Device
from src.config.config import EXTERNAL_API_CONFIG

logger = logging.getLogger(__name__)

class ServiceNowAPI:
    """
    Client for interacting with the ServiceNow API.
    
    This class provides methods for fetching Business Continuity Plans (BCP)
    from a ServiceNow instance.
    """
    
    def __init__(self):
        """Initialize the ServiceNow API client with configuration from config.py."""
        self.config = EXTERNAL_API_CONFIG.get("servicenow", {})
        self.base_url = self.config.get("base_url", "https://api.service-now.com")
        self.api_key = self.config.get("api_key", "")
        self.username = self.config.get("username", "")
        self.password = self.config.get("password", "")
        
        logger.info(f"Initialized ServiceNowAPI with base URL: {self.base_url}")
    
    def _get_auth_headers(self) -> Dict[str, str]:
        """
        Get authentication headers for ServiceNow API requests.
        
        Returns:
            A dictionary of authentication headers.
        """
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        
        return headers
    
    def _make_request(self, endpoint: str, method: str = "GET", params: Dict[str, Any] = None, data: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Make a request to the ServiceNow API.
        
        Args:
            endpoint: The API endpoint to request.
            method: The HTTP method to use.
            params: Query parameters for the request.
            data: JSON data for the request body.
            
        Returns:
            The JSON response from the API.
            
        Raises:
            Exception: If the request fails.
        """
        url = f"{self.base_url}{endpoint}"
        headers = self._get_auth_headers()
        
        try:
            auth = None
            if not self.api_key and self.username and self.password:
                auth = (self.username, self.password)
            
            logger.info(f"Making {method} request to {url}")
            
            if method == "GET":
                response = requests.get(url, headers=headers, params=params, auth=auth, timeout=30)
            elif method == "POST":
                response = requests.post(url, headers=headers, params=params, json=data, auth=auth, timeout=30)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
            
            response.raise_for_status()
            
            return response.json()
        
        except requests.exceptions.RequestException as e:
            logger.exception(f"Error making request to {url}: {str(e)}")
            
            if "get_bcp_plans" in endpoint:
                logger.warning("Using mock data for BCP plans due to API error")
                from src.mock_apis.servicenow.api import mock_servicenow_api
                app_codes = params.get("app_codes", []) if params else []
                return {"result": [plan.model_dump() for plan in mock_servicenow_api.get_bcp_plans_for_app_codes(app_codes)]}
            
            raise
    
    def get_bcp_plans_for_app_codes(self, app_codes: List[str]) -> List[DisasterRecoveryPlan]:
        """
        Get BCP plans for a list of application codes from the ServiceNow API.
        
        Args:
            app_codes: The list of application codes to get BCP plans for.
            
        Returns:
            A list of BCP plans for the specified application codes.
        """
        logger.info(f"Getting BCP plans for app codes: {app_codes}")
        
        try:
            response = self._make_request(
                endpoint="/api/now/table/bcp_plans",
                method="GET",
                params={"app_codes": ",".join(app_codes)}
            )
            
            plans = []
            
            for plan_data in response.get("result", []):
                tasks = []
                for task_data in plan_data.get("tasks", []):
                    task = RecoveryTask(
                        id=task_data.get("id", ""),
                        name=task_data.get("name", ""),
                        description=task_data.get("description", ""),
                        sequence=task_data.get("sequence", 0),
                        estimated_duration=task_data.get("estimated_duration", 0),
                        responsible_team=task_data.get("responsible_team", ""),
                        dependencies=task_data.get("dependencies", [])
                    )
                    tasks.append(task)
                
                devices = []
                for device_data in plan_data.get("devices", []):
                    device = Device(
                        id=device_data.get("id", ""),
                        name=device_data.get("name", ""),
                        type=device_data.get("type", ""),
                        description=device_data.get("description", ""),
                        app_code=device_data.get("app_code", "")
                    )
                    devices.append(device)
                
                created_at = datetime.fromisoformat(plan_data.get("created_at")) if isinstance(plan_data.get("created_at"), str) else datetime.now()
                updated_at = datetime.fromisoformat(plan_data.get("updated_at")) if isinstance(plan_data.get("updated_at"), str) else datetime.now()
                
                plan = DisasterRecoveryPlan(
                    id=plan_data.get("id", ""),
                    app_code=plan_data.get("app_code", ""),
                    name=plan_data.get("name", ""),
                    description=plan_data.get("description", ""),
                    version=plan_data.get("version", "1.0"),
                    created_at=created_at,
                    updated_at=updated_at,
                    recovery_time_objective=plan_data.get("recovery_time_objective", 0),
                    recovery_point_objective=plan_data.get("recovery_point_objective", 0),
                    tasks=tasks,
                    devices=devices
                )
                
                plans.append(plan)
            
            logger.info(f"Found {len(plans)} BCP plans for {len(app_codes)} app codes")
            
            return plans
        
        except Exception as e:
            logger.exception(f"Error getting BCP plans for app codes {app_codes}: {str(e)}")
            
            logger.warning("Using mock data for BCP plans due to API error")
            from src.mock_apis.servicenow.api import mock_servicenow_api
            return mock_servicenow_api.get_bcp_plans_for_app_codes(app_codes)
    
    def get_plan_by_id(self, plan_id: str) -> Optional[DisasterRecoveryPlan]:
        """
        Get a BCP plan by its ID from the ServiceNow API.
        
        Args:
            plan_id: The ID of the plan to get.
            
        Returns:
            The BCP plan with the specified ID, or None if not found.
        """
        logger.info(f"Getting BCP plan with ID: {plan_id}")
        
        try:
            response = self._make_request(
                endpoint=f"/api/now/table/bcp_plans/{plan_id}",
                method="GET"
            )
            
            plan_data = response.get("result", {})
            
            if not plan_data:
                logger.warning(f"BCP plan with ID {plan_id} not found")
                return None
            
            tasks = []
            for task_data in plan_data.get("tasks", []):
                task = RecoveryTask(
                    id=task_data.get("id", ""),
                    name=task_data.get("name", ""),
                    description=task_data.get("description", ""),
                    sequence=task_data.get("sequence", 0),
                    estimated_duration=task_data.get("estimated_duration", 0),
                    responsible_team=task_data.get("responsible_team", ""),
                    dependencies=task_data.get("dependencies", [])
                )
                tasks.append(task)
            
            devices = []
            for device_data in plan_data.get("devices", []):
                device = Device(
                    id=device_data.get("id", ""),
                    name=device_data.get("name", ""),
                    type=device_data.get("type", ""),
                    description=device_data.get("description", ""),
                    app_code=device_data.get("app_code", "")
                )
                devices.append(device)
            
            created_at = datetime.fromisoformat(plan_data.get("created_at")) if isinstance(plan_data.get("created_at"), str) else datetime.now()
            updated_at = datetime.fromisoformat(plan_data.get("updated_at")) if isinstance(plan_data.get("updated_at"), str) else datetime.now()
            
            plan = DisasterRecoveryPlan(
                id=plan_data.get("id", ""),
                app_code=plan_data.get("app_code", ""),
                name=plan_data.get("name", ""),
                description=plan_data.get("description", ""),
                version=plan_data.get("version", "1.0"),
                created_at=created_at,
                updated_at=updated_at,
                recovery_time_objective=plan_data.get("recovery_time_objective", 0),
                recovery_point_objective=plan_data.get("recovery_point_objective", 0),
                tasks=tasks,
                devices=devices
            )
            
            return plan
        
        except Exception as e:
            logger.exception(f"Error getting BCP plan with ID {plan_id}: {str(e)}")
            
            logger.warning("Using mock data for BCP plan due to API error")
            from src.mock_apis.servicenow.api import mock_servicenow_api
            return mock_servicenow_api.get_plan_by_id(plan_id)
    
    def get_all_plans(self) -> List[DisasterRecoveryPlan]:
        """
        Get all BCP plans from the ServiceNow API.
        
        Returns:
            A list of all BCP plans.
        """
        logger.info(f"Getting all BCP plans")
        
        try:
            response = self._make_request(
                endpoint="/api/now/table/bcp_plans",
                method="GET"
            )
            
            plans = []
            
            for plan_data in response.get("result", []):
                tasks = []
                for task_data in plan_data.get("tasks", []):
                    task = RecoveryTask(
                        id=task_data.get("id", ""),
                        name=task_data.get("name", ""),
                        description=task_data.get("description", ""),
                        sequence=task_data.get("sequence", 0),
                        estimated_duration=task_data.get("estimated_duration", 0),
                        responsible_team=task_data.get("responsible_team", ""),
                        dependencies=task_data.get("dependencies", [])
                    )
                    tasks.append(task)
                
                devices = []
                for device_data in plan_data.get("devices", []):
                    device = Device(
                        id=device_data.get("id", ""),
                        name=device_data.get("name", ""),
                        type=device_data.get("type", ""),
                        description=device_data.get("description", ""),
                        app_code=device_data.get("app_code", "")
                    )
                    devices.append(device)
                
                created_at = datetime.fromisoformat(plan_data.get("created_at")) if isinstance(plan_data.get("created_at"), str) else datetime.now()
                updated_at = datetime.fromisoformat(plan_data.get("updated_at")) if isinstance(plan_data.get("updated_at"), str) else datetime.now()
                
                plan = DisasterRecoveryPlan(
                    id=plan_data.get("id", ""),
                    app_code=plan_data.get("app_code", ""),
                    name=plan_data.get("name", ""),
                    description=plan_data.get("description", ""),
                    version=plan_data.get("version", "1.0"),
                    created_at=created_at,
                    updated_at=updated_at,
                    recovery_time_objective=plan_data.get("recovery_time_objective", 0),
                    recovery_point_objective=plan_data.get("recovery_point_objective", 0),
                    tasks=tasks,
                    devices=devices
                )
                
                plans.append(plan)
            
            logger.info(f"Found {len(plans)} BCP plans")
            
            return plans
        
        except Exception as e:
            logger.exception(f"Error getting all BCP plans: {str(e)}")
            
            logger.warning("Using mock data for BCP plans due to API error")
            from src.mock_apis.servicenow.api import mock_servicenow_api
            return mock_servicenow_api.get_all_plans()

servicenow_api = ServiceNowAPI()
