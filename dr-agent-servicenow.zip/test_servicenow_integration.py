"""
Test script to verify the ServiceNow integration with the DR Plans Fetcher Agent.
"""

import logging
import sys
from src.agents.dr_plans_fetcher.agent import dr_plans_fetcher_agent

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    stream=sys.stdout
)

def test_servicenow_integration():
    """Test the ServiceNow integration with the DR Plans Fetcher Agent."""
    print("Testing DR Plans Fetcher Agent with ServiceNow integration...")
    
    app_codes = ["APP001", "APP002", "APP003"]
    print(f"\nFetching plans from ServiceNow for app codes: {app_codes}")
    servicenow_result = dr_plans_fetcher_agent.fetch_plans(app_codes)
    print(f"Fetched {servicenow_result['plan_count']} plans from {servicenow_result['source']}")
    
    print(f"\nFetching plans from Postgres for app codes: {app_codes}")
    postgres_result = dr_plans_fetcher_agent.fetch_plans(app_codes, use_servicenow=False)
    print(f"Fetched {postgres_result['plan_count']} plans from {postgres_result['source']}")
    
    assert servicenow_result['source'] == 'ServiceNow', "ServiceNow API source not correctly identified"
    assert postgres_result['source'] == 'Postgres', "Postgres API source not correctly identified"
    
    print("\nServiceNow integration test passed successfully!")
    return True

if __name__ == "__main__":
    test_servicenow_integration()
