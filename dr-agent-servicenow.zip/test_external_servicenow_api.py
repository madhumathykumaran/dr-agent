"""
Test script to verify the external ServiceNow API integration with the DR Plans Fetcher Agent.

This script tests the DR Plans Fetcher Agent's ability to connect to and fetch data from
the external ServiceNow API.

Usage:
    python test_external_servicenow_api.py

Environment Variables:
    USE_EXTERNAL_SERVICENOW: Set to "true" to use the external ServiceNow API
    SERVICENOW_API_URL: The URL of the ServiceNow API
    SERVICENOW_API_KEY: API key for authentication
    SERVICENOW_USERNAME: Username for basic authentication
    SERVICENOW_PASSWORD: Password for basic authentication
"""

import logging
import os
import sys
import json
from datetime import datetime

os.environ["USE_EXTERNAL_SERVICENOW"] = "true"
os.environ["SERVICENOW_API_URL"] = "https://api.service-now.com"
os.environ["SERVICENOW_API_KEY"] = "test_api_key"  # Replace with actual API key for real testing
os.environ["SERVICENOW_USERNAME"] = "test_user"    # Replace with actual username for real testing
os.environ["SERVICENOW_PASSWORD"] = "test_pass"    # Replace with actual password for real testing

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    stream=sys.stdout
)

logger = logging.getLogger(__name__)

from src.agents.dr_plans_fetcher.agent import dr_plans_fetcher_agent
from src.apis.servicenow.api import servicenow_api
from src.config.config import EXTERNAL_API_CONFIG

def test_external_servicenow_api_config():
    """Test that the external ServiceNow API configuration is correctly loaded."""
    logger.info("Testing external ServiceNow API configuration...")
    
    servicenow_config = EXTERNAL_API_CONFIG.get("servicenow", {})
    
    assert servicenow_config.get("base_url") == "https://api.service-now.com", "ServiceNow API URL not correctly configured"
    assert servicenow_config.get("api_key") == "test_api_key", "ServiceNow API key not correctly configured"
    assert servicenow_config.get("username") == "test_user", "ServiceNow username not correctly configured"
    assert servicenow_config.get("password") == "test_pass", "ServiceNow password not correctly configured"
    
    logger.info("External ServiceNow API configuration test passed!")
    return True

def test_servicenow_api_client_initialization():
    """Test that the ServiceNow API client is correctly initialized."""
    logger.info("Testing ServiceNow API client initialization...")
    
    assert servicenow_api is not None, "ServiceNow API client not initialized"
    assert servicenow_api.base_url == "https://api.service-now.com", "ServiceNow API client base URL not correctly set"
    
    logger.info("ServiceNow API client initialization test passed!")
    return True

def test_dr_plans_fetcher_agent_initialization():
    """Test that the DR Plans Fetcher Agent is correctly initialized with the external ServiceNow API."""
    logger.info("Testing DR Plans Fetcher Agent initialization...")
    
    assert dr_plans_fetcher_agent is not None, "DR Plans Fetcher Agent not initialized"
    assert dr_plans_fetcher_agent.use_external_servicenow, "DR Plans Fetcher Agent not using external ServiceNow API"
    assert dr_plans_fetcher_agent.servicenow_api is not None, "DR Plans Fetcher Agent ServiceNow API not initialized"
    
    logger.info("DR Plans Fetcher Agent initialization test passed!")
    return True

def test_fetch_plans_from_external_servicenow():
    """Test fetching plans from the external ServiceNow API."""
    logger.info("Testing fetching plans from external ServiceNow API...")
    
    app_codes = ["APP001", "APP002", "APP003"]
    
    result = dr_plans_fetcher_agent.fetch_plans(app_codes, use_servicenow=True)
    
    assert result is not None, "Fetch plans result is None"
    assert result["source"] == "ServiceNow", "Source not correctly identified as ServiceNow"
    assert "servicenow_api_type" in result, "ServiceNow API type not included in result"
    assert result["servicenow_api_type"] == "external", "ServiceNow API type not correctly identified as external"
    assert result["plan_count"] > 0, "No plans fetched from ServiceNow API"
    assert len(result["plans"]) == result["plan_count"], "Plan count does not match number of plans"
    
    logger.info(f"Successfully fetched {result['plan_count']} plans from external ServiceNow API")
    
    if result["plan_count"] > 0:
        first_plan = result["plans"][0]
        logger.info(f"First plan: {first_plan['name']} (ID: {first_plan['id']}) for app code {first_plan['app_code']}")
        logger.info(f"  RTO: {first_plan['recovery_time_objective']} minutes, RPO: {first_plan['recovery_point_objective']} minutes")
        logger.info(f"  Tasks: {len(first_plan['tasks'])}, Devices: {len(first_plan['devices'])}")
    
    logger.info("Fetch plans from external ServiceNow API test passed!")
    return True

def test_process_message_with_external_servicenow():
    """Test processing a message with the external ServiceNow API."""
    logger.info("Testing processing a message with external ServiceNow API...")
    
    message = {
        "app_codes": ["APP001", "APP002", "APP003"],
        "use_servicenow": True
    }
    
    result = dr_plans_fetcher_agent.process_message(message)
    
    assert result is not None, "Process message result is None"
    assert result["status"] == "success", f"Process message failed: {result.get('message', 'Unknown error')}"
    assert "data" in result, "Process message result does not contain data"
    assert result["data"]["source"] == "ServiceNow", "Source not correctly identified as ServiceNow"
    assert "servicenow_api_type" in result["data"], "ServiceNow API type not included in result"
    assert result["data"]["servicenow_api_type"] == "external", "ServiceNow API type not correctly identified as external"
    
    logger.info("Process message with external ServiceNow API test passed!")
    return True

def test_generate_reply_with_external_servicenow():
    """Test generating a reply with the external ServiceNow API."""
    logger.info("Testing generating a reply with external ServiceNow API...")
    
    message = {
        "app_codes": ["APP001", "APP002", "APP003"],
        "use_servicenow": True
    }
    
    reply = dr_plans_fetcher_agent.generate_reply(message)
    
    assert reply is not None, "Generate reply result is None"
    assert "content" in reply, "Generate reply result does not contain content"
    assert "plans_data" in reply, "Generate reply result does not contain plans_data"
    assert reply["plans_data"]["status"] == "success", f"Generate reply failed: {reply['plans_data'].get('message', 'Unknown error')}"
    assert reply["plans_data"]["data"]["source"] == "ServiceNow", "Source not correctly identified as ServiceNow"
    
    logger.info("Generate reply with external ServiceNow API test passed!")
    return True

def run_all_tests():
    """Run all tests for the external ServiceNow API integration."""
    logger.info("Starting external ServiceNow API integration tests...")
    
    tests = [
        test_external_servicenow_api_config,
        test_servicenow_api_client_initialization,
        test_dr_plans_fetcher_agent_initialization,
        test_fetch_plans_from_external_servicenow,
        test_process_message_with_external_servicenow,
        test_generate_reply_with_external_servicenow
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            if test():
                passed += 1
            else:
                failed += 1
        except Exception as e:
            logger.exception(f"Test {test.__name__} failed with error: {str(e)}")
            failed += 1
    
    logger.info(f"Test results: {passed} passed, {failed} failed")
    
    return failed == 0

if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
