"""
ServiceNow API client for the Disaster Recovery Compliance Agent System.

This module provides a client for interacting with the ServiceNow API to fetch
Business Continuity Plans (BCP).
"""

from src.apis.servicenow.api import ServiceNowAPI, servicenow_api

__all__ = ["ServiceNowAPI", "servicenow_api"]
