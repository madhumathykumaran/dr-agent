"""
DR Plans Fetcher Agent for the Disaster Recovery Compliance Agent System.

This agent is responsible for fetching disaster recovery plans from a Postgres database table
and/or Business Continuity Plans (BCP) from ServiceNow.
"""

import logging
import os
import json
from typing import List, Dict, Any, Optional

from autogen import AssistantAgent

from src.mock_apis.postgres.api import mock_postgres_api
from src.mock_apis.servicenow.api import mock_servicenow_api
try:
    from src.apis.servicenow.api import servicenow_api as external_servicenow_api
    EXTERNAL_SERVICENOW_AVAILABLE = True
except ImportError:
    EXTERNAL_SERVICENOW_AVAILABLE = False
    
from src.models.data_models import DisasterRecoveryPlan
from src.config.config import AGENT_CONFIG, LLM_CONFIG, EXTERNAL_API_CONFIG

logger = logging.getLogger(__name__)

class DRPlansFetcherAgent:
    """
    Agent responsible for fetching disaster recovery plans from a Postgres database
    and/or Business Continuity Plans (BCP) from ServiceNow.
    
    This agent uses the appropriate API to fetch plans for a list of
    application codes and passes the results to the next agent in the workflow.
    """
    
    def __init__(self):
        """Initialize the DR Plans Fetcher Agent."""
        self.config = AGENT_CONFIG["dr_plans_fetcher_agent"]
        self.postgres_api = mock_postgres_api
        
        self.use_external_servicenow = EXTERNAL_SERVICENOW_AVAILABLE and os.getenv("USE_EXTERNAL_SERVICENOW", "False").lower() == "true"
        
        if self.use_external_servicenow:
            logger.info("Using external ServiceNow API")
            self.servicenow_api = external_servicenow_api
        else:
            logger.info("Using mock ServiceNow API")
            self.servicenow_api = mock_servicenow_api
            
        self.use_servicenow = True
        
        try:
            self.agent = AssistantAgent(
                name=self.config["name"],
                system_message=self._create_system_message(),
                llm_config=LLM_CONFIG
            )
        except Exception as e:
            logger.warning(f"Failed to initialize AssistantAgent: {str(e)}")
            self.agent = type('MockAgent', (), {
                'name': self.config["name"],
                'system_message': self._create_system_message(),
                'generate_reply': lambda message, *args, **kwargs: {
                    "content": f"Mock reply from {self.config['name']}",
                    "role": "assistant"
                }
            })()
        
        logger.info(f"Initialized {self.config['name']} with {'external' if self.use_external_servicenow else 'mock'} ServiceNow API")
    
    def _create_system_message(self) -> str:
        """
        Create the system message for the agent.
        
        Returns:
            The system message string.
        """
        servicenow_api_type = "external" if self.use_external_servicenow else "mock"
        
        return f"""
        You are the {self.config['name']}, responsible for fetching disaster recovery plans
        from a Postgres database table and/or Business Continuity Plans (BCP) from ServiceNow.
        
        {self.config['description']}
        
        You have access to both Postgres and ServiceNow APIs to fetch plans for a list of
        application codes. You are currently configured to use the {servicenow_api_type} ServiceNow API.
        
        When given a list of application codes, you should:
        1. Fetch plans for each application code from the appropriate source
        2. Compile a complete list of all plans and their details
        3. Format the results in a structured way for the next agent
        
        Your output should include:
        - The application codes for which plans were fetched
        - All plans and their details
        - The recovery tasks for each plan
        - The devices for each plan
        - The source of the plans (Postgres or ServiceNow)
        - The type of ServiceNow API used (external or mock)
        """
    
    def fetch_plans(self, app_codes: List[str], use_servicenow: Optional[bool] = None) -> Dict[str, Any]:
        """
        Fetch plans for a list of application codes.
        
        Args:
            app_codes: The list of application codes to fetch plans for.
            use_servicenow: Whether to use ServiceNow API (True) or Postgres API (False).
                           If None, uses the agent's default setting.
            
        Returns:
            A dictionary containing the plans and related information.
        """
        try:
            use_servicenow_api = self.use_servicenow if use_servicenow is None else use_servicenow
            api_source = "ServiceNow" if use_servicenow_api else "Postgres"
            
            # Determine which ServiceNow API implementation is being used (external or mock)
            servicenow_api_type = None
            if use_servicenow_api:
                servicenow_api_type = "external" if self.use_external_servicenow else "mock"
                logger.info(f"Fetching plans from {api_source} ({servicenow_api_type}) for app codes: {app_codes}")
            else:
                logger.info(f"Fetching plans from {api_source} for app codes: {app_codes}")
            
            if use_servicenow_api:
                plans = self.servicenow_api.get_bcp_plans_for_app_codes(app_codes)
            else:
                plans = self.postgres_api.get_plans_for_app_codes(app_codes)
            
            serialized_plans = []
            for plan in plans:
                serialized_plan = plan.model_dump()
                serialized_plan["created_at"] = plan.created_at.isoformat()
                serialized_plan["updated_at"] = plan.updated_at.isoformat()
                serialized_plans.append(serialized_plan)
            
            result = {
                "app_codes": app_codes,
                "plans": serialized_plans,
                "plan_count": len(serialized_plans),
                "source": api_source
            }
            
            if use_servicenow_api and servicenow_api_type:
                result["servicenow_api_type"] = servicenow_api_type
            
            if use_servicenow_api:
                logger.info(f"Fetched {len(serialized_plans)} plans from {api_source} ({servicenow_api_type}) for {len(app_codes)} app codes")
            else:
                logger.info(f"Fetched {len(serialized_plans)} plans from {api_source} for {len(app_codes)} app codes")
            
            return result
        
        except Exception as e:
            logger.exception(f"Error fetching plans for app codes: {app_codes}")
            raise
    
    def process_message(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process a message from another agent.
        
        Args:
            message: The message to process.
            
        Returns:
            A dictionary containing the response.
        """
        try:
            app_codes = []
            use_servicenow = None  # Default to agent's setting
            
            if "app_codes" in message:
                app_codes = message["app_codes"]
            
            elif "dependencies_data" in message and "data" in message["dependencies_data"]:
                data = message["dependencies_data"]["data"]
                if "all_app_codes" in data:
                    app_codes = data["all_app_codes"]
            
            if "use_servicenow" in message:
                use_servicenow = message["use_servicenow"]
                logger.info(f"Message specified use_servicenow={use_servicenow}")
            
            if not app_codes:
                return {
                    "status": "error",
                    "message": "No application codes provided"
                }
            
            plans_result = self.fetch_plans(app_codes, use_servicenow)
            
            response = {
                "status": "success",
                "message": f"Fetched {plans_result['plan_count']} plans from {plans_result['source']} for {len(app_codes)} application codes",
                "data": plans_result
            }
            
            return response
        
        except Exception as e:
            logger.exception(f"Error processing message: {message}")
            
            return {
                "status": "error",
                "message": f"Error processing message: {str(e)}"
            }
    
    def generate_reply(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a reply to a message using the AG2 agent.
        
        Args:
            message: The message to reply to.
            
        Returns:
            A dictionary containing the reply.
        """
        plans_result = self.process_message(message)
        
        formatted_message = self._format_message_for_agent(plans_result)
        
        reply = self.agent.generate_reply(formatted_message)
        
        if isinstance(reply, dict):
            reply["plans_data"] = plans_result
        else:
            reply = {
                "content": reply,
                "plans_data": plans_result
            }
        
        return reply
    
    def _format_message_for_agent(self, plans_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Format a plans result as a message for the AG2 agent.
        
        Args:
            plans_result: The plans result to format.
            
        Returns:
            A dictionary containing the formatted message.
        """
        if plans_result["status"] == "error":
            return {
                "content": f"Error: {plans_result['message']}"
            }
        
        data = plans_result["data"]
        app_codes = data["app_codes"]
        plans = data["plans"]
        plan_count = data["plan_count"]
        source = data["source"]
        
        api_type_info = ""
        if source == "ServiceNow" and "servicenow_api_type" in data:
            api_type_info = f" using the {data['servicenow_api_type']} ServiceNow API"
        
        message = f"""
        I have fetched {plan_count} plans from {source}{api_type_info} for the following application codes:
        {', '.join(app_codes)}
        
        Here is a summary of the plans:
        """
        
        for plan in plans:
            app_code = plan["app_code"]
            name = plan["name"]
            description = plan["description"]
            version = plan["version"]
            rto = plan["recovery_time_objective"]
            rpo = plan["recovery_point_objective"]
            task_count = len(plan["tasks"])
            device_count = len(plan["devices"])
            
            message += f"\n- Plan for {app_code}: {name} (v{version})"
            message += f"\n  RTO: {rto} minutes, RPO: {rpo} minutes"
            message += f"\n  {task_count} recovery tasks, {device_count} devices"
            message += f"\n  Description: {description[:100]}..."
        
        message += f"\n\nThe complete plan details from {source}{api_type_info} are available in the structured data."
        
        return {
            "content": message,
            "role": "assistant"
        }

dr_plans_fetcher_agent = DRPlansFetcherAgent()
