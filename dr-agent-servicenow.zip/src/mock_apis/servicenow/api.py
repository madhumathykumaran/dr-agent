"""
Mock ServiceNow API for the Disaster Recovery Compliance Agent System.

This module provides a mock implementation of the ServiceNow API for fetching
Business Continuity Plans (BCP).
"""

import logging
import random
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional

from src.models.data_models import DisasterRecoveryPlan, RecoveryTask, Device

logger = logging.getLogger(__name__)

class MockServiceNowAPI:
    """
    Mock implementation of the ServiceNow API.
    
    This class provides methods for fetching Business Continuity Plans (BCP)
    from a mock ServiceNow instance.
    """
    
    def __init__(self):
        """Initialize the mock ServiceNow API with sample data."""
        self.plans = self._generate_mock_bcp_plans()
        logger.info(f"Initialized MockServiceNowAPI with {len(self.plans)} mock BCP plans")
    
    def _generate_mock_bcp_plans(self) -> List[DisasterRecoveryPlan]:
        """
        Generate mock Business Continuity Plans (BCP).
        
        Returns:
            A list of mock BCP plans using the DisasterRecoveryPlan model.
        """
        plans = []
        
        for i in range(1, 11):
            app_code = f"APP{i:03d}"
            
            tasks = []
            for j in range(1, random.randint(4, 8)):
                task = RecoveryTask(
                    id=f"BCP_TASK{i}{j:02d}",
                    name=f"BCP Recovery Task {j} for {app_code}",
                    description=f"ServiceNow BCP recovery task {j} for application {app_code}.",
                    sequence=j,
                    estimated_duration=random.randint(10, 90),
                    responsible_team=random.choice(["Business Continuity Team", "Application Support", "Infrastructure Team", "Cloud Operations"]),
                    dependencies=[f"BCP_TASK{i}{k:02d}" for k in range(1, j) if random.random() < 0.3]
                )
                tasks.append(task)
            
            devices = []
            for j in range(1, random.randint(2, 6)):
                device = Device(
                    id=f"BCP_DEV{i}{j:02d}",
                    name=f"BCP Device {j} for {app_code}",
                    type=random.choice(["Virtual Server", "Container", "Database Cluster", "Storage Array"]),
                    description=f"ServiceNow BCP device {j} for application {app_code}.",
                    app_code=app_code
                )
                devices.append(device)
            
            created_at = datetime.now() - timedelta(days=random.randint(10, 180))
            updated_at = created_at + timedelta(days=random.randint(1, 10))
            
            plan = DisasterRecoveryPlan(
                id=f"BCP_PLAN{i:03d}",
                app_code=app_code,
                name=f"Business Continuity Plan for {app_code}",
                description=f"ServiceNow BCP plan for application {app_code}. This plan details the business continuity procedures and recovery strategies.",
                version=f"2.{random.randint(0, 9)}",
                created_at=created_at,
                updated_at=updated_at,
                recovery_time_objective=random.choice([30, 60, 180, 360, 720]),  # in minutes
                recovery_point_objective=random.choice([5, 15, 30, 60, 120]),  # in minutes
                tasks=tasks,
                devices=devices
            )
            
            plans.append(plan)
        
        return plans
    
    def get_bcp_plans_for_app_codes(self, app_codes: List[str]) -> List[DisasterRecoveryPlan]:
        """
        Get BCP plans for a list of application codes.
        
        Args:
            app_codes: The list of application codes to get BCP plans for.
            
        Returns:
            A list of BCP plans for the specified application codes.
        """
        logger.info(f"Getting BCP plans for app codes: {app_codes}")
        
        matching_plans = [plan for plan in self.plans if plan.app_code in app_codes]
        
        logger.info(f"Found {len(matching_plans)} BCP plans for {len(app_codes)} app codes")
        
        return matching_plans
    
    def get_plan_by_id(self, plan_id: str) -> Optional[DisasterRecoveryPlan]:
        """
        Get a BCP plan by its ID.
        
        Args:
            plan_id: The ID of the plan to get.
            
        Returns:
            The BCP plan with the specified ID, or None if not found.
        """
        logger.info(f"Getting BCP plan with ID: {plan_id}")
        
        for plan in self.plans:
            if plan.id == plan_id:
                return plan
        
        logger.warning(f"BCP plan with ID {plan_id} not found")
        
        return None
    
    def get_all_plans(self) -> List[DisasterRecoveryPlan]:
        """
        Get all BCP plans.
        
        Returns:
            A list of all BCP plans.
        """
        logger.info(f"Getting all BCP plans")
        
        return self.plans

mock_servicenow_api = MockServiceNowAPI()
