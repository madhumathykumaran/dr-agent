from flask import Flask, render_template_string, redirect, url_for
import markdown2
import os

app = Flask(__name__)

def get_html_template(title):
    """Return the HTML template with the given title."""
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>{title}</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            body {{
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                line-height: 1.6;
                color: #333;
                max-width: 900px;
                margin: 0 auto;
                padding: 20px;
            }}
            h1, h2, h3, h4, h5, h6 {{
                margin-top: 24px;
                margin-bottom: 16px;
                font-weight: 600;
                line-height: 1.25;
            }}
            h1 {{
                font-size: 2em;
                border-bottom: 1px solid #eaecef;
                padding-bottom: .3em;
            }}
            h2 {{
                font-size: 1.5em;
                border-bottom: 1px solid #eaecef;
                padding-bottom: .3em;
            }}
            pre {{
                background-color: #f6f8fa;
                border-radius: 3px;
                padding: 16px;
                overflow: auto;
            }}
            code {{
                background-color: rgba(27,31,35,.05);
                border-radius: 3px;
                font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace;
                font-size: 85%;
                padding: 0.2em 0.4em;
            }}
            pre code {{
                background-color: transparent;
                padding: 0;
            }}
            blockquote {{
                border-left: 4px solid #dfe2e5;
                color: #6a737d;
                padding: 0 1em;
                margin: 0;
            }}
            table {{
                border-collapse: collapse;
                width: 100%;
                margin: 16px 0;
            }}
            table th, table td {{
                border: 1px solid #dfe2e5;
                padding: 6px 13px;
            }}
            table tr {{
                background-color: #fff;
                border-top: 1px solid #c6cbd1;
            }}
            table tr:nth-child(2n) {{
                background-color: #f6f8fa;
            }}
            .version-selector {{
                position: fixed;
                top: 10px;
                right: 10px;
                background-color: #f1f1f1;
                padding: 10px;
                border-radius: 5px;
                box-shadow: 0 2px 5px rgba(0,0,0,0.1);
                z-index: 1000;
            }}
            .version-selector a {{
                margin: 0 10px;
                text-decoration: none;
                color: #0366d6;
                font-weight: bold;
            }}
            .version-selector a:hover {{
                text-decoration: underline;
            }}
            .version-selector .active {{
                color: #24292e;
                cursor: default;
            }}
            .version-selector .active:hover {{
                text-decoration: none;
            }}
        </style>
    </head>
    <body>
        <div class="version-selector">
            <a href="/" class="{v1_active}">Original Version</a> | 
            <a href="/v2" class="{v2_active}">Version 2 (with Diagrams)</a>
        </div>
        {{ content|safe }}
    </body>
    </html>
    """.format(
        title=title,
        v1_active="active" if title == "Disaster Recovery Compliance Agent System Whitepaper" else "",
        v2_active="active" if title == "Disaster Recovery Compliance Agent System Whitepaper v2" else ""
    )

@app.route('/')
def index():
    """Serve the original README.md content."""
    with open('README.md', 'r') as f:
        content = f.read()
    
    html_content = markdown2.markdown(content, extras=["tables", "fenced-code-blocks"])
    template = get_html_template("Disaster Recovery Compliance Agent System Whitepaper")
    
    return render_template_string(template, content=html_content)

@app.route('/v2')
def index_v2():
    """Serve the README_v2.md content with enhanced diagrams."""
    with open('README_v2.md', 'r') as f:
        content = f.read()
    
    html_content = markdown2.markdown(content, extras=["tables", "fenced-code-blocks"])
    template = get_html_template("Disaster Recovery Compliance Agent System Whitepaper v2")
    
    return render_template_string(template, content=html_content)

@app.route('/health')
def health():
    """Health check endpoint."""
    return {"status": "healthy"}

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8080))
    app.run(host='0.0.0.0', port=port)
